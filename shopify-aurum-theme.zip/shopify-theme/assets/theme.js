// Image switcher
function switchImg(idx) {
  document.querySelectorAll('.hero-img-stack img').forEach((el, i) => {
    el.classList.toggle('active', i === idx);
  });
  document.querySelectorAll('.thumb').forEach((el, i) => {
    el.classList.toggle('active', i === idx);
  });
}

// Auto-cycle images
var current = 0;
var imgCount = document.querySelectorAll('.hero-img-stack img').length;
if (imgCount > 1) {
  setInterval(function() {
    current = (current + 1) % imgCount;
    switchImg(current);
  }, 4000);
}

// Scroll reveal
var reveals = document.querySelectorAll('.reveal');
var observer = new IntersectionObserver(function(entries) {
  entries.forEach(function(entry, i) {
    if (entry.isIntersecting) {
      setTimeout(function() {
        entry.target.classList.add('visible');
      }, i * 80);
    }
  });
}, { threshold: 0.12 });

reveals.forEach(function(el) { observer.observe(el); });

// Nav blur on scroll
window.addEventListener('scroll', function() {
  var nav = document.getElementById('main-nav');
  if (!nav) return;
  if (window.scrollY > 40) {
    nav.style.backdropFilter = 'blur(16px)';
    nav.style.background = 'rgba(10,9,7,0.92)';
  } else {
    nav.style.backdropFilter = 'blur(0px)';
    nav.style.background = 'linear-gradient(to bottom, rgba(10,9,7,0.97) 0%, rgba(10,9,7,0) 100%)';
  }
});
